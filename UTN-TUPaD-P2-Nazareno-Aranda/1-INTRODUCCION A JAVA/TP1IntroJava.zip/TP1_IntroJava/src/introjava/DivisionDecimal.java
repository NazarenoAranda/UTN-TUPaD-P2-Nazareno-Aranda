/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package introjava;

/**
 *
 * @author Usuario
 */
import java.util.Scanner;

public class DivisionDecimal {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el primer numero: ");
        double a = entrada.nextDouble();

        System.out.print("Ingrese el segundo numero: ");
        double b = entrada.nextDouble();

        double resultado = a / b;

        System.out.println("Resultado (decimal): " + resultado);
    }
}

