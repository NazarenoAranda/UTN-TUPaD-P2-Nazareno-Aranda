/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package introjava;

/**
 *
 * @author Usuario
 */
import java.util.Scanner;

public class DivisionEntera {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el primer numero: ");
        int a = entrada.nextInt();

        System.out.print("Ingrese el segundo numero: ");
        int b = entrada.nextInt();

        int resultado = a / b;

        System.out.println("Resultado (entero): " + resultado);
    }
}

